import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import pandas as pd
import numpy as np


class RegionReader:
    def __init__(self, file_paths):
        self.file_paths = file_paths
        self.dataframes = {}

    #reads weather data from files, adds a year column, and stores dataframes by region name
    def read_csv_files(self):
        for file_path in self.file_paths:
            df = pd.read_csv(file_path, skiprows=3, low_memory=False)
    
            df['time'] = pd.to_datetime(df['time'], errors='coerce')
            df.dropna(subset=['time'], inplace=True)
            df['year'] = df['time'].dt.year

            region_name = file_path.split('/')[-1].replace('open-meteo-', '').replace('.csv', '')
            self.dataframes[region_name] = df
            
    #reads latitude and longitude from the second line of each file 
    def get_coordinates(self):
        coordinates = {}
        for file_path in self.file_paths:
            with open(file_path, 'r') as f:
                lines = [line.strip() for line in f if line.strip()] 
                lat_lon_line = lines[1].split(',')
                lat = float(lat_lon_line[0])
                lon = float(lat_lon_line[1])
        
            region_name = file_path.split('/')[-1].replace('open-meteo-', '').replace('.csv', '')
            coordinates[region_name] = (lat, lon)
        return coordinates



class WeatherStatistics:
    def __init__(self, dataframes):
        self.dataframes = dataframes
        
    #plots the annual average temperature for all regions
    def plot_yearly_avg_temperature(self):
        plt.figure(figsize=(10, 6))

        for region, df in self.dataframes.items():
            if 'temperature_2m (°C)' not in df.columns or 'year' not in df.columns:
                print(f"Skipping {region}: required columns not found.")
                continue

            yearly_avg = df.groupby('year')['temperature_2m (°C)'].mean()

            plt.plot(yearly_avg.index, yearly_avg.values, label=region)

        plt.title('Yearly Average Temperature by Region')
        plt.xlabel('Year')
        plt.ylabel('Average Temperature (°C)')
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        plt.show()

    #plots total precipitation for each half-year period, separately for each region
    def plot_halfyearly_precipitation_by_region(self):
        for region, df in self.dataframes.items():
            precip_col = next((col for col in df.columns if 'precipitation' in col.lower()), None)

            if precip_col is None or 'time' not in df.columns:
                print(f"Skipping {region}: missing required columns.")
                continue

            df['half_year'] = df['time'].dt.year.astype(str) + "-" + df['time'].dt.month.apply(lambda m: 'H1' if m <= 6 else 'H2')
            halfyearly_sum = df.groupby('half_year')[precip_col].sum().reset_index()

            if halfyearly_sum.empty:
                print(f"No precipitation data for {region}")
                continue

            plt.figure(figsize=(8, 4))
            plt.bar(halfyearly_sum['half_year'], halfyearly_sum[precip_col], color='skyblue')
            plt.title(f"Half-Yearly Total Precipitation - {region.title()}")
            plt.xlabel("Half-Year")
            plt.ylabel("Total Precipitation (mm)")
            plt.xticks(rotation=45)
            plt.grid(True, axis='y')
            plt.tight_layout()
            plt.show()

    #plots half-yearly average humidity over time for all regions   
    def plot_halfyearly_avg_humidity(self):
        plt.figure(figsize=(10, 6))

        for region, df in self.dataframes.items():
            humidity_col = next((col for col in df.columns if 'humidity' in col.lower()), None)

            if humidity_col is None or 'time' not in df.columns:
                print(f"Skipping {region}: required columns not found.")
                continue
            df['half_year'] = df['time'].dt.year.astype(str) + "-" + df['time'].dt.month.apply(lambda m: 'H1' if m <= 6 else 'H2')
            halfyearly_avg = df.groupby('half_year')[humidity_col].mean()
            halfyearly_avg = halfyearly_avg.reset_index()
            halfyearly_avg['half_year_order'] = pd.to_datetime(
                halfyearly_avg['half_year'].str.replace('H1', '01-01').str.replace('H2', '07-01')
            )
            halfyearly_avg = halfyearly_avg.sort_values('half_year_order')

            plt.plot(halfyearly_avg['half_year_order'], halfyearly_avg[humidity_col], label=region)

        plt.title('Half-Yearly Average Humidity by Region')
        plt.xlabel('Half-Year')
        plt.ylabel('Average Humidity (%)')
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        plt.show()
 
        
    
#file paths
file_paths = [
    "./Regions/open-meteo-Berlin.csv",
    "./Regions/open-meteo-Cairo.csv",
    "./Regions/open-meteo-LosAngeles.csv",
    "./Regions/open-meteo-Sydney.csv",
    "./Regions/open-meteo-Moscow.csv"
]

#loading data
region_reader = RegionReader(file_paths)
region_reader.read_csv_files()
coordinates = region_reader.get_coordinates()

weather_stats = WeatherStatistics(region_reader.dataframes)
weather_stats.plot_yearly_avg_temperature()
weather_stats.plot_halfyearly_precipitation_by_region()
weather_stats.plot_halfyearly_avg_humidity()



#displays a global map using Cartopy, color-coded by average temperature
region_stats = {}
for region, df in weather_stats.dataframes.items():
    avg_temp = df['temperature_2m (°C)'].mean() if 'temperature_2m (°C)' in df.columns else None
    avg_precip = df['precipitation_sum (mm)'].mean() if 'precipitation_sum (mm)' in df.columns else None
    region_stats[region] = {'avg_temp': avg_temp, 'avg_precip': avg_precip}

plt.figure(figsize=(12, 6))
ax = plt.axes(projection=ccrs.PlateCarree())
ax.set_global()

ax.coastlines()
ax.add_feature(cfeature.BORDERS, linestyle=':')
ax.add_feature(cfeature.LAND, facecolor='lightgray')
ax.add_feature(cfeature.OCEAN, facecolor='lightblue')

import matplotlib.cm as cm
import matplotlib.colors as mcolors

norm = mcolors.Normalize(vmin=0, vmax=25)  
cmap = cm.get_cmap('coolwarm')

for region, (lat, lon) in coordinates.items():
    avg_temp = region_stats[region]['avg_temp']

    color = cmap(norm(avg_temp)) if avg_temp is not None else 'gray'
    size = 0.1 * 1000

    ax.scatter(lon, lat, color=color, s=size, edgecolor='black', transform=ccrs.PlateCarree(), alpha=0.8)
    ax.text(lon + 2, lat + 2, f"{region}\n{avg_temp:.1f}°C", transform=ccrs.PlateCarree(), fontsize=9, weight='bold')

plt.colorbar(cm.ScalarMappable(norm=norm, cmap=cmap), ax=ax, orientation='vertical', label='Avg Temperature (°C)')

plt.title('Regions: Color-coded by Avg Temp')
plt.tight_layout()
plt.show()



#for each region, computes and plots linear temperature trends
for region, df in weather_stats.dataframes.items():
    yearly_avg = df.groupby('year')['temperature_2m (°C)'].mean()

    slope, intercept = np.polyfit(yearly_avg.index, yearly_avg.values, 1)

    plt.figure(figsize=(8, 4))
    plt.plot(yearly_avg.index, yearly_avg.values, label='Observed', marker='o')
    plt.plot(yearly_avg.index, slope * yearly_avg.index + intercept, label=f'Trend ({slope:.2f} °C/year)', linestyle='--')
    plt.title(f"Yearly Avg Temperature & Trend - {region}")
    plt.xlabel('Year')
    plt.ylabel('Avg Temperature (°C)')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()


    #prints summaries for each region: yearly average temperature, precipitation, and humidity.
    #also prints averages for the most recent 10 years
    for region, df in weather_stats.dataframes.items():
        print(f"\n=== Summary for {region} ===")
    
    if 'temperature_2m (°C)' in df.columns:
        print("\nYearly Average Temperature (°C):")
        print(df.groupby('year')['temperature_2m (°C)'].mean()) 
    else:
        print('No temperature data.')
    
    if 'precipitation (mm)' in df.columns:
        print("\nYearly Total Precipitation (mm):")
        print(df.groupby('year')['precipitation (mm)'].sum())
    else:
        print('No precipitation data.')
    
    if 'relative_humidity_2m (%)' in df.columns:
        print("\nYearly Average Humidity (%):")
        print(df.groupby('year')['relative_humidity_2m (%)'].mean())
    else:
        print('No humidity data.')
    
    print("\nRecent 10 years (averages):")
    columns = [col for col in ['temperature_2m (°C)', 'precipitation (mm)', 'relative_humidity_2m (%)'] if col in df.columns]
    print(df.groupby('year')[columns].mean().tail(10))
    
    
"""REPORT:
Weather Patterns Comparison Between Regions:

Temperature patterns:
    -Cairo and Los Angeles show the highest average yearly temperatures (around 18-19°C), 
    reflecting their warm and dry subtropical climates.
    --Sydney shows a more moderate climate (17-18°C) with less fluctuation.
    Berlin and Moscow are the coldest, with Moscow averaging around 5°C, 
    indicating its cold continental climate. Temperature increases over the decades are visible in all regions, 
    especially in Moscow, where the warming trend is above 0.03°C/year, confirming that cold regions are warming faster.

Percipitation patterns: 
    -Cairo and Los Angeles are very dry, with very low half-yearly and yearly precipitation.
    -Sydney and Berlin show higher precipitation, fitting its humid subtropical climate.
    -Moscow also shows moderate precipitation, but combined with lower temperatures, indicating cold and wet winters.

Humidity patterns:
    -Cairo has consistently low humidity (<40%), matching its desert climate.
    -Moscow, Berlin, and Sydney show higher average humidity (~60-70%), typical for temperate and coastal regions.
    
Long term changes over the decades:
    -All regions show a warming trend, confirmed by linear regression analysis:
        -Moscow and Berlin have the most pronounced warming 
        -Cairo and Los Angeles show a smaller, but still clear warming trend 
    -Precipitation trends are more variable:
        -Los Angeles and Cairo remain consistently dry.
        -Sydney and Berlin show slight variability but no strong upward or downward trend.

Conclusion: 
    -The data clearly shows a warming trend across all regions, with the most noticeable changes occurring in colder areas such as Moscow.
    -While each region continues to show its own typical climate characteristics, the effects of global warming are evident everywhere — with cooler regions heating up more rapidly than warmer, drier areas like Cairo or Los Angeles.
    -If these patterns persist, it's likely that these areas will face more extreme and unpredictable weather events in the future.
"""
    
    
    
    
    
    