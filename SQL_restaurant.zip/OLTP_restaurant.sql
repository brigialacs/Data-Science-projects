--select * from import

drop table if exists OrderedItems
drop table if exists EmployeeOrders
drop table if exists Reservations
drop table if exists Payments
drop table if exists orders
drop table if exists menuingredients
drop table if exists MenuItems
drop table if exists category
drop table if exists ingredients
drop table if exists tables
drop table if exists Customers
drop table if exists employees
drop table if exists employeerole


create table EmployeeRole
(RoleID int identity not null primary key,
Name varchar(100))

create table Employees
(EmployeeID int identity not null primary key,
Name varchar(100),
RoleID int not null foreign key references EmployeeRole(RoleID))

create table Customers
(CustomerID int identity not null primary key,
Name varchar(100),
Email varchar(100),
PhoneNumber varchar(100))

create table Tables
(TableNo int not null primary key,
Capacity varchar(100))

create table Category
(CategoryID int identity not null primary key,
Name varchar(100))

create table Ingredients
(IngredientID int identity not null primary key,
Name varchar(100),
Stock int)

create table MenuItems
(MenuItemID int identity not null primary key,
Name varchar(100),
Price float,
CategoryID int not null foreign key references Category(CategoryID))

create table MenuIngredients
(MenuItemID int not null foreign key references MenuItems(MenuItemID),
IngredientID int not null foreign key references Ingredients(IngredientID))

Create table Orders
(OrderID int not null primary key,
CustomerID int not null foreign key references Customers(CustomerID),
TableID int foreign key references Tables(TableNo),
OrderDate date,
TotalCost float,
OrderType varchar(100))

create table Reservations
(ReservationID int identity not null primary key,
ReservationDate date,
ReservationTime time,
Reserved_TableID int not null,
CustomerID int not null foreign key references Customers(CustomerID))
--OrderID int not null foreign key references Restaurant.Orders(OrderID))

create table Payments
(PaymentID int identity not null primary key,
OrderID int not null foreign key references Orders(OrderID),
PaymentAmount float,
PaymentStatus varchar(100),
PaymentMethod varchar(100))

create table EmployeeOrders
(EmployeeID int not null foreign key references Employees(EmployeeID),
OrderID int not null foreign key references Orders(OrderID))

create table OrderedItems
(MenuItemID int not null foreign key references MenuItems(MenuItemID),
OrderID int not null foreign key references Orders(OrderID),
SpecialRequest varchar(100))

--DATA POPULATION

insert into EmployeeRole
select distinct Staff_Role from import

insert into Employees
select distinct im.staff_name, er.RoleID from import im
join EmployeeRole er on im.Staff_Role=er.Name

insert into Customers
select distinct Customer_Name, Customer_Email, Customer_Phone from import 

--Capacity was not included in the dataset
insert into Tables
select distinct Table_Number, 'Not Found' from import

insert into Category
select distinct Menu_Category from import

insert into MenuItems
select distinct im.Menu_Item, im.Menu_Item_Price, c.categoryID from import im
join Category c on im.Menu_Category=c.Name

--We don't have data on what type of order it was
insert into Orders
select distinct im.Order_ID, c.customerID, im.Table_Number, im.Order_Date,
 im.total_cost, 'Dine-in/Takeaway' from import im
 left join Customers c on im.Customer_Email=c.Email

 insert into Reservations
 select distinct im.Reservation_Date, im.Reservation_Time, im.Reservation_Table_Number,
 c.customerID from import im
 join Customers c on c.name=im.Customer_Name

 --We don't have payment method specified in out dataset
 insert into payments 
 select distinct o.OrderID, im.Payment_Amount, im.Payment_Status, 'Not Found'
 from import im
 join Orders o on o.OrderDate=im.Order_Date

 insert into EmployeeOrders
 select distinct e.employeeid, o.orderid from import im
 left join Orders o on o.OrderID=im.Order_ID
 left join Employees e on e.name=im.Staff_Name

 insert into OrderedItems
 select distinct m.menuitemid, o.orderid, im.special_requests from import im
 left join MenuItems m on im.Menu_Item=m.name
 left join Orders o on o.OrderID=im.Order_ID

--select * from EmployeeRole
--select * from Employees
--select * from Customers
--select * from Tables
--select * from Category
--select * from MenuItems
--select * from Orders
--select * from Reservations
--select * from Payments
--select * from EmployeeOrders
--select * from OrderedItems
