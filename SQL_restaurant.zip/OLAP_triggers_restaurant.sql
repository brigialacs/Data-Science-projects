drop table if exists FactOrder
drop table if exists DimMenuItem
drop table if exists DimCustomer
drop table if exists DimReservation
drop table if exists DimEmployee
drop table if exists DimDate


Create table DimDate 
(DateKey date not null primary key,
Year int not null,
Quarter int not null,
Month int not null,
Day int not null)

Create table DimEmployee
(EmployeeKey int identity not null primary key,
EmployeeID int not null,
Name varchar (100),
Role varchar(100))

Create table DimReservation
(ReservationKey int identity not null primary key,
ReservationID int not null,
ReservationDate date,
ReservationTime time)

create table DimCustomer
(CustomerKey int identity not null primary key,
CustomerID int not null,
Name varchar(100),
Email varchar(100),
PhoneNumber varchar(100))

create table DimMenuItem
(MenuItemKey int identity not null primary key,
MenuItemID int not null,
Name varchar(100),
Category varchar (100),
Price decimal (10,2))

create table FactOrder
(OrderKey int identity not null primary key,
OrderID int not null,
DateKey date not null foreign key references DimDate(DateKey),
CustomerKey int not null foreign key references DimCustomer(CustomerKey),
EmployeeKey int not null foreign key references DimEmployee(EmployeeKey),
ReservationKey int foreign key references DimReservation(ReservationKey),
MenuItemKey int not null foreign key references DimMenuItem(MenuItemKey),
OrderType varchar (100),
Quantity int,
TotalCost decimal(10,2))


--DATA POPULATION

declare @minDate date, @maxDate date
select @minDate=min(OrderDate), @maxDate=max(OrderDate) from Orders
while @minDate <= @maxDate
begin 
insert into DimDate (DateKey, Year, Quarter, Month, Day)
values(
@minDate, year(@minDate), datepart(quarter, @minDate), month(@minDate), day(@minDate))
set @minDate= dateadd(day,1,@minDate)
end

go

insert into DimEmployee (EmployeeID, Name, Role)
select e.EmployeeID, e.Name, r.Name from Employees e
join EmployeeRole r on e.RoleID = r.RoleID

insert into DimReservation (ReservationId, ReservationDate, ReservationTime)
select ReservationID, ReservationDate, ReservationTime from Reservations 

insert into DimCustomer(CustomerID, Name, Email, PhoneNumber)
select CustomerID, Name, Email, PhoneNumber from Customers

insert into DimMenuItem (MenuItemID, Name, Category, Price)
select m.MenuItemID, m.Name, c.Name, m.Price from MenuItems m
join Category c on m.CategoryID=c.CategoryID

insert into FactOrder(OrderID, DateKey, CustomerKey, EmployeeKey, ReservationKey, MenuItemKey, OrderType, Quantity,TotalCost)
select distinct
	o.OrderID,
	o.OrderDate, 
	c.CustomerKey,
	e.EmployeeKey,
	r.ReservationKey,
	m.MenuItemKey,
	o.OrderType,
	count(m.MenuItemID) over (partition by oi.OrderID, m.MenuItemID) as Quantity,
	o.TotalCost
from Orders o
join OrderedItems oi on oi.OrderID = o.OrderID
join EmployeeOrders eo on eo.OrderID = o.OrderID
join Customers cu on cu.CustomerID = o.CustomerID
LEFT join Reservations re on re.CustomerID = cu.CustomerID 
LEFT join DimReservation r on r.ReservationID = re.ReservationID
join DimEmployee e on e.EmployeeID = eo.EmployeeID
join DimMenuItem m on m.MenuItemID = oi.MenuItemID
join DimCustomer c on o.CustomerID = c.CustomerID
join DimDate d on o.OrderDate = d.DateKey
order by o.OrderID asc

--select * from FactOrder
--select * from DimCustomer
--select * from DimDate
--select * from DimEmployee
--select * from DimMenuItem
--select * from DimReservation
go

--UPDATE OLAP for Customers

create or alter trigger trg_dimcustomer
on Customers
after insert, update, delete
as
begin
set nocount on
--handling deleted records
delete dc
from DimCustomer dc
inner join deleted d on dc.CustomerID=d.CustomerID
end
go
 
--HANDLING INSERT/UPDATE CASES
merge DimCustomer as target
using (
	select CustomerID, Name, Email, PhoneNumber
	from Customers
) as source
on target.CustomerID=source.CustomerID
when matched then
	update set
	target.Name=source.Name,
	target.Email=source.Email,
	target.PhoneNumber=source.PhoneNumber
when not matched by target then
	insert (CustomerID, Name, Email, PhoneNumber)
	values (source.CustomerID, source.Name, source.Email, source.PhoneNumber);
